import face_recognition
import os
import pickle
from config import DATASET_PATH, EMBEDDING_PATH

encodings = []
ids = []

for user_id in os.listdir(DATASET_PATH):
    user_path = os.path.join(DATASET_PATH, user_id)

    for img in os.listdir(user_path):
        path = os.path.join(user_path, img)

        image = face_recognition.load_image_file(path)
        faces = face_recognition.face_encodings(image)

        if faces:
            encodings.append(faces[0])
            ids.append(int(user_id))

os.makedirs("data/embeddings", exist_ok=True)

with open(EMBEDDING_PATH, "wb") as f:
    pickle.dump({"encodings": encodings, "ids": ids}, f)

print("Embeddings generated")