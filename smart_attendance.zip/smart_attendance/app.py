import cv2
import face_recognition
import pickle
import numpy as np
import time

from config import EMBEDDING_PATH
from database import mark_attendance, connect_db

# ==============================
# LOAD DATA
# ==============================
with open(EMBEDDING_PATH, "rb") as f:
    data = pickle.load(f)

known_encodings = data["encodings"]
known_ids = data["ids"]

# Load user names
conn = connect_db()
cursor = conn.cursor()
cursor.execute("SELECT user_id, name FROM users")
user_map = {row[0]: row[1] for row in cursor.fetchall()}
conn.close()

# ==============================
# CAMERA
# ==============================
cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

if not cap.isOpened():
    print("Camera error")
    exit()

print("\n[INFO] Advanced Attendance System Running...\n")

# ==============================
# SETTINGS
# ==============================
last_mark_time = {}
COOLDOWN = 15
CONF_THRESHOLD = 60

# Tracking
tracker = None
tracking = False

# ==============================
# MAIN LOOP
# ==============================
while True:
    ret, frame = cap.read()
    if not ret:
        break

    display_frame = frame.copy()

    # ==========================
    # TRACKING MODE
    # ==========================
    if tracking:
        success, box = tracker.update(frame)

        if success:
            x, y, w, h = map(int, box)
            cv2.rectangle(display_frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
        else:
            tracking = False

    # ==========================
    # DETECTION MODE
    # ==========================
    if not tracking:
        small = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
        rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)

        # Use 'cnn' if GPU available, else 'hog'
        face_locations = face_recognition.face_locations(rgb, model='hog')
        face_encodings = face_recognition.face_encodings(rgb, face_locations)

        if len(face_locations) > 0:

            # 🔥 Select largest face (ignore background)
            largest_index = max(
                range(len(face_locations)),
                key=lambda i: (face_locations[i][2] - face_locations[i][0]) *
                              (face_locations[i][1] - face_locations[i][3])
            )

            encoding = face_encodings[largest_index]
            (top, right, bottom, left) = face_locations[largest_index]

            # Scale back
            top *= 2
            right *= 2
            bottom *= 2
            left *= 2

            name = "Unknown"
            confidence = 0

            distances = face_recognition.face_distance(known_encodings, encoding)

            if len(distances) > 0:
                best_index = np.argmin(distances)
                distance = distances[best_index]

                confidence = max(0, (1 - distance) * 100)

                if confidence >= CONF_THRESHOLD:
                    user_id = known_ids[best_index]
                    name = user_map.get(user_id, "Unknown")

                    current_time = time.time()

                    if user_id not in last_mark_time:
                        mark_attendance(user_id)
                        last_mark_time[user_id] = current_time
                    else:
                        if current_time - last_mark_time[user_id] > COOLDOWN:
                            mark_attendance(user_id)
                            last_mark_time[user_id] = current_time

                    # Start tracking
                    tracker = cv2.TrackerKCF_create()
                    bbox = (left, top, right-left, bottom-top)
                    tracker.init(frame, bbox)
                    tracking = True

            label = f"{name} ({confidence:.2f}%)"

            cv2.rectangle(display_frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(display_frame, label, (left, top - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

    cv2.imshow("Smart Attendance System", display_frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()