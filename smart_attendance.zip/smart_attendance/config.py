DATABASE_PATH = "data/attendance.db"
DATASET_PATH = "data/dataset"
EMBEDDING_PATH = "data/embeddings/encodings.pkl"