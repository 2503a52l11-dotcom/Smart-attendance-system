import cv2
import os
from config import DATASET_PATH

user_id = input("Enter User ID: ")

path = os.path.join(DATASET_PATH, user_id)
os.makedirs(path, exist_ok=True)

cap = cv2.VideoCapture(0)
count = 0

print("Press C to capture (20 images)")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    cv2.imshow("Capture", frame)
    key = cv2.waitKey(1)

    if key == ord('c'):
        cv2.imwrite(f"{path}/{count}.jpg", frame)
        print("Saved", count)
        count += 1

    if count >= 20:
        break

cap.release()
cv2.destroyAllWindows()