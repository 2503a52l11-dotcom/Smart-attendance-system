import sqlite3
import os
from datetime import datetime
from config import DATABASE_PATH

def connect():
    os.makedirs("data", exist_ok=True)
    return sqlite3.connect(DATABASE_PATH)

def create_tables():
    conn = connect()
    c = conn.cursor()

    c.execute("""
    CREATE TABLE IF NOT EXISTS users(
        user_id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        role TEXT,
        username TEXT UNIQUE,
        password TEXT
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS attendance(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        date TEXT,
        in_time TEXT,
        out_time TEXT
    )
    """)

    conn.commit()
    conn.close()

def register(name, role, username, password):
    conn = connect()
    c = conn.cursor()

    c.execute("SELECT * FROM users WHERE username=?", (username,))
    if c.fetchone():
        return None

    c.execute("INSERT INTO users(name,role,username,password) VALUES (?,?,?,?)",
              (name, role, username, password))

    conn.commit()
    uid = c.lastrowid
    conn.close()
    return uid

def login(username, password):
    conn = connect()
    c = conn.cursor()

    c.execute("SELECT user_id,name,role FROM users WHERE username=? AND password=?",
              (username, password))

    user = c.fetchone()
    conn.close()
    return user

def mark_in(user_id):
    conn = connect()
    c = conn.cursor()

    today = datetime.now().date().isoformat()
    now = datetime.now().isoformat()

    c.execute("SELECT * FROM attendance WHERE user_id=? AND date=?",
              (user_id, today))

    if c.fetchone():
        return "Already IN"

    c.execute("INSERT INTO attendance(user_id,date,in_time,out_time) VALUES (?,?,?,NULL)",
              (user_id, today, now))

    conn.commit()
    conn.close()
    return "IN marked"

def mark_out(user_id):
    conn = connect()
    c = conn.cursor()

    today = datetime.now().date().isoformat()
    now = datetime.now().isoformat()

    c.execute("SELECT id,out_time FROM attendance WHERE user_id=? AND date=?",
              (user_id, today))

    record = c.fetchone()

    if not record:
        return "Mark IN first"

    rid, out_time = record

    if out_time:
        return "Already OUT"

    c.execute("UPDATE attendance SET out_time=? WHERE id=?", (now, rid))

    conn.commit()
    conn.close()
    return "OUT marked"