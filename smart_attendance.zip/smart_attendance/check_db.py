from database import connect_db

conn = connect_db()
cursor = conn.cursor()

print("USERS:")
cursor.execute("SELECT * FROM users")
for row in cursor.fetchall():
    print(row)

print("\nATTENDANCE:")
cursor.execute("SELECT * FROM attendance")
for row in cursor.fetchall():
    print(row)

conn.close()