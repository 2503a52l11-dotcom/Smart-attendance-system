import streamlit as st
import sqlite3
import cv2
import face_recognition
import pickle
import numpy as np
import pandas as pd
import os
from datetime import datetime

# ================= CONFIG =================
DB_PATH = "data/attendance.db"
EMBED_PATH = "data/embeddings/encodings.pkl"

# ================= DB =================
def connect():
    os.makedirs("data", exist_ok=True)
    return sqlite3.connect(DB_PATH)

def init_db():
    conn = connect()
    c = conn.cursor()

    c.execute("""
    CREATE TABLE IF NOT EXISTS users(
        user_id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        role TEXT,
        username TEXT UNIQUE,
        password TEXT
    )
    """)

    c.execute("""
    CREATE TABLE IF NOT EXISTS attendance(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        date TEXT,
        in_time TEXT,
        out_time TEXT
    )
    """)

    conn.commit()
    conn.close()

def register(name, role, username, password):
    conn = connect()
    c = conn.cursor()

    c.execute("SELECT * FROM users WHERE username=?", (username,))
    if c.fetchone():
        return None

    c.execute("INSERT INTO users(name,role,username,password) VALUES (?,?,?,?)",
              (name, role, username, password))
    conn.commit()
    uid = c.lastrowid
    conn.close()
    return uid

def login(username, password):
    conn = connect()
    c = conn.cursor()
    c.execute("SELECT user_id,name,role FROM users WHERE username=? AND password=?",
              (username, password))
    user = c.fetchone()
    conn.close()
    return user

def mark_in(user_id):
    conn = connect()
    c = conn.cursor()
    today = datetime.now().date().isoformat()
    now = datetime.now().isoformat()

    c.execute("SELECT * FROM attendance WHERE user_id=? AND date=?", (user_id, today))
    if c.fetchone():
        return "Already IN"

    c.execute("INSERT INTO attendance(user_id,date,in_time,out_time) VALUES (?,?,?,NULL)",
              (user_id, today, now))
    conn.commit()
    conn.close()
    return "IN marked"

def mark_out(user_id):
    conn = connect()
    c = conn.cursor()
    today = datetime.now().date().isoformat()
    now = datetime.now().isoformat()

    c.execute("SELECT id,out_time FROM attendance WHERE user_id=? AND date=?",
              (user_id, today))
    rec = c.fetchone()
    if not rec:
        return "Mark IN first"

    rid, out_time = rec
    if out_time:
        return "Already OUT"

    c.execute("UPDATE attendance SET out_time=? WHERE id=?", (now, rid))
    conn.commit()
    conn.close()
    return "OUT marked"

# ================= FACE =================
def load_embeddings():
    if not os.path.exists(EMBED_PATH):
        return None, None
    with open(EMBED_PATH, "rb") as f:
        data = pickle.load(f)
    enc = np.array(data["encodings"], dtype=np.float32)
    ids = np.array(data["ids"], dtype=np.int32)

    # normalize stored encodings
    norms = np.linalg.norm(enc, axis=1, keepdims=True)
    enc = enc / np.maximum(norms, 1e-8)
    return enc, ids

def recognize_single(frame, known_enc, known_ids, threshold=0.45):
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    faces = face_recognition.face_locations(rgb)
    encs = face_recognition.face_encodings(rgb, faces)

    if len(faces) == 0:
        return None, 0.0, "No face"
    if len(faces) > 1:
        return None, 0.0, "Multiple faces"

    # normalize query encoding
    q = encs[0]
    q = q / max(np.linalg.norm(q), 1e-8)

    distances = face_recognition.face_distance(known_enc, q)
    idx = int(np.argmin(distances))
    d = float(distances[idx])
    conf = max(0.0, (1.0 - d)) * 100.0

    if d > threshold:
        return None, conf, f"Not recognized (d={d:.3f})"

    return int(known_ids[idx]), conf, "OK"

# ================= INIT =================
init_db()
st.set_page_config(page_title="Smart Attendance", layout="wide")

# ================= SESSION =================
for k, v in {
    "login": False,
    "uid": None,
    "role": None,
    "name": None
}.items():
    if k not in st.session_state:
        st.session_state[k] = v

# ================= LOGIN =================
if not st.session_state.login:
    st.title("🎓 Smart Attendance System")

    tab1, tab2 = st.tabs(["Login", "Register"])

    with tab1:
        u = st.text_input("Username", key="login_user")
        p = st.text_input("Password", type="password", key="login_pass")

        if st.button("Login"):
            user = login(u, p)
            if user:
                st.session_state.login = True
                st.session_state.uid = user[0]
                st.session_state.name = user[1]
                st.session_state.role = user[2]
                st.rerun()
            else:
                st.error("Invalid credentials")

    with tab2:
        name = st.text_input("Name", key="reg_name")
        role = st.selectbox("Role", ["Student", "Staff"], key="reg_role")
        u = st.text_input("Username", key="reg_user")
        p = st.text_input("Password", type="password", key="reg_pass")

        if st.button("Register"):
            if register(name, role, u, p):
                st.success("Registered successfully")
            else:
                st.error("Username already exists")

    st.stop()

# ================= LOAD DATA =================
conn = connect()
users = pd.read_sql("SELECT * FROM users", conn)
attendance = pd.read_sql("SELECT * FROM attendance", conn)
conn.close()

data = attendance.merge(users, on="user_id", how="left")
uid = st.session_state.uid
role = st.session_state.role

# ================= SIDEBAR =================
if role == "Staff":
    menu = st.sidebar.selectbox("Menu", ["Dashboard", "Live Face Attendance", "Export"])
else:
    menu = st.sidebar.selectbox("Menu", ["My Attendance", "Mark Attendance (Buttons)", "Live Face Attendance"])

if st.sidebar.button("Logout"):
    st.session_state.clear()
    st.rerun()

# ================= STUDENT =================
if role == "Student":

    if menu == "My Attendance":
        st.subheader("My Attendance")
        my = data[data["user_id"] == uid]
        st.dataframe(my, use_container_width=True)

        # stats
        total = len(my)
        present = my["in_time"].notna().sum()
        st.metric("Total Records", total)
        st.metric("IN Marked", present)

    elif menu == "Mark Attendance (Buttons)":
        st.subheader("Manual Attendance")

        col1, col2 = st.columns(2)
        if col1.button("IN"):
            st.success(mark_in(uid))
        if col2.button("OUT"):
            st.success(mark_out(uid))

    elif menu == "Live Face Attendance":
        st.subheader("Live Face (with Tracking)")

        known_enc, known_ids = load_embeddings()
        if known_enc is None:
            st.error("Embeddings not found. Generate them first.")
            st.stop()

        run = st.checkbox("Start Camera")
        frame_window = st.image([])

        if run:
            cap = cv2.VideoCapture(0)

            while True:
                ret, frame = cap.read()
                if not ret:
                    break

                small = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
                rgb = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)

                faces = face_recognition.face_locations(rgb)
                encs = face_recognition.face_encodings(rgb, faces)

                if len(faces) == 1:
                    (top, right, bottom, left) = faces[0]
                    top, right, bottom, left = [v * 2 for v in (top, right, bottom, left)]

                    # recognize
                    detected_id, conf, msg = recognize_single(frame, known_enc, known_ids)

                    color = (0, 0, 255)
                    label = msg

                    if detected_id is not None:
                        color = (0, 255, 0)
                        label = f"ID:{detected_id} ({conf:.1f}%)"

                        if detected_id == uid:
                            action = mark_in(uid)
                            if action == "Already IN":
                                action = mark_out(uid)
                            st.success(action)
                        else:
                            st.error("Not your face")

                    cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
                    cv2.putText(frame, label, (left, top - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

                elif len(faces) > 1:
                    cv2.putText(frame, "Multiple faces!", (30, 30),
                                cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

                frame_window.image(frame, channels="BGR")

                if not run:
                    break

            cap.release()

# ================= STAFF =================
else:

    if menu == "Dashboard":
        st.subheader("All Attendance")
        st.dataframe(data, use_container_width=True)

        # ---- Charts ----
        st.markdown("### 📊 Analytics")

        if not data.empty:
            # daily
            daily = data.groupby("date").size().reset_index(name="count")
            st.line_chart(daily.set_index("date"))

            # status
            data["status"] = data["out_time"].apply(
                lambda x: "Present" if pd.notna(x) else "Incomplete"
            )
            st.bar_chart(data["status"].value_counts())

            # per student
            per_student = data.groupby("name").size().sort_values(ascending=False)
            st.bar_chart(per_student)

    elif menu == "Live Face Attendance":
        st.subheader("Staff Face Marking")

        known_enc, known_ids = load_embeddings()
        if known_enc is None:
            st.error("Embeddings not found.")
            st.stop()

        if st.button("Capture"):
            cap = cv2.VideoCapture(0)
            ret, frame = cap.read()
            cap.release()

            st.image(frame, channels="BGR")

            detected_id, conf, msg = recognize_single(frame, known_enc, known_ids)
            if detected_id is None:
                st.error(msg)
            else:
                action = mark_in(detected_id)
                if action == "Already IN":
                    action = mark_out(detected_id)
                st.success(f"User {detected_id} → {action} ({conf:.1f}%)")

    elif menu == "Export":
        file = "attendance.xlsx"
        data.to_excel(file, index=False)
        with open(file, "rb") as f:
            st.download_button("Download Excel", f, file)